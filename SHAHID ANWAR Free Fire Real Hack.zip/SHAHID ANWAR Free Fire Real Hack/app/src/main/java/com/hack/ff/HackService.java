package com.hack.ff;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class HackService extends Service {

    private WindowManager windowManager;
    private View floatingView;
    private TextView tvStatus;
    private SeekBar sbHealth, sbDamage;
    private Button btnPos, btnAntiCheat, btnInvisible;
    private Handler uiHandler = new Handler(Looper.getMainLooper());
    private boolean isRunning = true;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        floatingView = inflater.inflate(R.layout.layout_float, null);

        tvStatus = floatingView.findViewById(R.id.tvStatus);
        sbHealth = floatingView.findViewById(R.id.sbHealth);
        sbDamage = floatingView.findViewById(R.id.sbDamage);
        btnPos = floatingView.findViewById(R.id.btnPos);
        btnAntiCheat = floatingView.findViewById(R.id.btnAntiCheat);
        btnInvisible = floatingView.findViewById(R.id.btnInvisible);

        // Bind UI to JNI
        sbHealth.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) JNIHelper.setHealth((float) progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        sbDamage.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) JNIHelper.setDamage((float) progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnPos.setOnClickListener(v -> {
            JNIHelper.setPosition(100.0f, 50.0f, 100.0f);
            tvStatus.setText("Teleported!");
        });

        btnAntiCheat.setOnClickListener(v -> {
            JNIHelper.toggleAntiCheatBypass(true);
            tvStatus.setText("Anti-Cheat: BYPASSED");
        });

        btnInvisible.setOnClickListener(v -> {
            JNIHelper.toggleInvisibility(true);
            tvStatus.setText("Invisible: ON");
        });

        // Add Overlay
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 50;
        params.y = 100;
        windowManager.addView(floatingView, params);

        // Sync UI with Memory
        startSyncThread();
    }

    private void startSyncThread() {
        new Thread(() -> {
            while (isRunning) {
                try {
                    Thread.sleep(500);
                    float health = JNIHelper.getCurrentHealth();
                    float damage = JNIHelper.getCurrentDamage();

                    uiHandler.post(() -> {
                        if (sbHealth.getProgress() != (int) health) {
                            sbHealth.setProgress((int) health);
                        }
                        if (sbDamage.getProgress() != (int) damage) {
                            sbDamage.setProgress((int) damage);
                        }
                        tvStatus.setText("H: " + (int)health + " | D: " + (int)damage);
                    });
                } catch (Exception e) { e.printStackTrace(); }
            }
        }).start();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (floatingView != null) windowManager.removeView(floatingView);
    }
}