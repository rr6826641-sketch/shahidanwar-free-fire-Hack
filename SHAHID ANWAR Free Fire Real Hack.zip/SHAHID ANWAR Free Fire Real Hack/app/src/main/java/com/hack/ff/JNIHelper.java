package com.hack.ff;

public class JNIHelper {
    static {
        System.loadLibrary("hack");
    }

    // Initialize Hack
    public static native void initHack(int pid);

    // Memory Manipulation
    public static native void setHealth(float value);
    public static native void setDamage(float value);
    public static native void setPosition(float x, float y, float z);
    
    // Read Memory for UI
    public static native float getCurrentHealth();
    public static native float getCurrentDamage();
    
    // Anti-Cheat & Invisibility
    public static native void toggleAntiCheatBypass(boolean enable);
    public static native void toggleInvisibility(boolean enable);
}