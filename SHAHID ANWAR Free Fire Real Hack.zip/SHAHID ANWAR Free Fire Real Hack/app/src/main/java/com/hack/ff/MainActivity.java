package com.hack.ff;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnStart = findViewById(R.id.btnStartHack);
        btnStart.setOnClickListener(v -> {
            // Start Floating Menu Service
            Intent serviceIntent = new Intent(this, HackService.class);
            startService(serviceIntent);

            // Initialize Native Hack
            JNIHelper.initHack(android.os.Process.myPid());
        });
    }
}