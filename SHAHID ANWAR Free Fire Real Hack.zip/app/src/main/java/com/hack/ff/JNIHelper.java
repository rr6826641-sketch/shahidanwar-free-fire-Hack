package com.hack.ff;

public class JNIHelper {

    static {
        // Isse system tere C++ library (libhack.so) ko load karega
        System.loadLibrary("hack");
    }

    // Native Methods declaration (C++ se match karna chahiye)
    public static native void initHack(int pid);
    public static native void setHealth(float value);
    public static native float getCurrentHealth();
    public static native void setPosition(float x, float y, float z);
    public static native void toggleAntiCheatBypass(boolean enable);
    public static native void toggleInvisibility(boolean enable);
    
    // Damage ke liye agar chahiye toh yeh bhi add kar sakta hai
    public static native void setDamage(float value);
    public static native float getCurrentDamage();
}