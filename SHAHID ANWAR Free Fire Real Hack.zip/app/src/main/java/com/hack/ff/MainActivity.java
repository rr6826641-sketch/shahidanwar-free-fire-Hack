package com.hack.ff;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView tvHealth;
    private Button btnInit, btnSetHp100, btnSetHp50, btnInvis, btnAntiCheat;
    private boolean isHackInitialized = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI Elements
        tvHealth = findViewById(R.id.tvHealth);
        btnInit = findViewById(R.id.btnInit);
        btnSetHp100 = findViewById(R.id.btnSetHp100);
        btnSetHp50 = findViewById(R.id.btnSetHp50);
        btnInvis = findViewById(R.id.btnInvis);
        btnAntiCheat = findViewById(R.id.btnAntiCheat);

        // Button Click Listeners
        btnInit.setOnClickListener(v -> {
            initHackProcess();
        });

        btnSetHp100.setOnClickListener(v -> {
            if (isHackInitialized) {
                JNIHelper.setHealth(100.0f);
                Toast.makeText(this, "HP Set to 100", Toast.LENGTH_SHORT).show();
            }
        });

        btnSetHp50.setOnClickListener(v -> {
            if (isHackInitialized) {
                JNIHelper.setHealth(50.0f);
                Toast.makeText(this, "HP Set to 50", Toast.LENGTH_SHORT).show();
            }
        });

        btnInvis.setOnClickListener(v -> {
            JNIHelper.toggleInvisibility(true);
            Toast.makeText(this, "Invisibility ON", Toast.LENGTH_SHORT).show();
        });

        btnAntiCheat.setOnClickListener(v -> {
            JNIHelper.toggleAntiCheatBypass(true);
            Toast.makeText(this, "Anti-Cheat Bypass ON", Toast.LENGTH_SHORT).show();
        });

        // Auto Update Health Display
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isHackInitialized) {
                    float hp = JNIHelper.getCurrentHealth();
                    tvHealth.setText("Current HP: " + (int)hp);
                }
                new Handler().postDelayed(this, 500); // Update every 0.5 sec
            }
        }, 1000);
    }

    private void initHackProcess() {
        // Get Process ID (PID) of Free Fire
        // Note: For simplicity, we use Android's own PID or pass FF's PID if running as Service
        int pid = android.os.Process.myPid(); 
        
        // Agar tu Free Fire ka PID pass karna chahta hai, toh wahan logic badal dega
        // Abhi ke liye hum assume kar rahe hain ki ye panel FF ke upar chal raha hai
        
        JNIHelper.initHack(pid);
        isHackInitialized = true;
        Toast.makeText(this, "Hack Initialized! Check Logcat.", Toast.LENGTH_LONG).show();
    }
}