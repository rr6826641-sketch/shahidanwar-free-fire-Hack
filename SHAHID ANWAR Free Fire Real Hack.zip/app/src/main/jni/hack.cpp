#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>
#include <thread>
#include <mutex>
#include <string.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "FFHack", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "FFHack", __VA_ARGS__)

// Global State
uintptr_t libil2cpp_Base = 0;
uintptr_t g_PlayerBase = 0;

// OFFSETS (Update these if needed)
const uintptr_t OFFSET_PLAYER_BASE_FROM_IL2CPP = 0x114A500; 
const uintptr_t OFFSET_HP_FROM_PLAYER_BASE = 0x140;         
const uintptr_t OFFSET_MAX_HP_FROM_PLAYER_BASE = 0x144;     
const uintptr_t OFFSET_TEAM_INDEX_FROM_PLAYER_BASE = 0x194; 

std::mutex g_mutex;

// Helper: Get Base Address of libil2cpp.so
uintptr_t getLibBase(pid_t pid, const char* libName) {
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* fp = fopen(path, "r");
    if (!fp) return 0;

    char line[256];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, libName)) {
            uintptr_t base = (uintptr_t)strtol(line, NULL, 16);
            fclose(fp);
            return base;
        }
    }
    fclose(fp);
    return 0;
}

// Helper: Read Memory Value
template <typename T>
T readMemory(uintptr_t addr) {
    T value;
    memcpy(&value, (void*)addr, sizeof(T));
    return value;
}

// Helper: Write Memory Value
template <typename T>
void writeMemory(uintptr_t addr, T value) {
    memcpy((void*)addr, &value, sizeof(T));
}

// JNI: Initialize Hack
extern "C" JNIEXPORT void JNICALL
Java_com_hack_ff_JNIHelper_initHack(JNIEnv *env, jobject thiz, jint pid) {
    LOGI("Initializing Hack for PID: %d", pid);
    
    libil2cpp_Base = getLibBase(pid, "libil2cpp.so");
    if (libil2cpp_Base == 0) {
        LOGE("libil2cpp.so not found!");
        return;
    }

    g_PlayerBase = libil2cpp_Base + OFFSET_PLAYER_BASE_FROM_IL2CPP;
    LOGI("PlayerBase Address: %lx", g_PlayerBase);
}

// JNI: Set Health
extern "C" JNIEXPORT void JNICALL
Java_com_hack_ff_JNIHelper_setHealth(JNIEnv *env, jobject thiz, jfloat value) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_PlayerBase) {
        uintptr_t hpAddr = g_PlayerBase + OFFSET_HP_FROM_PLAYER_BASE;
        writeMemory<float>(hpAddr, value);
        LOGI("HP Set to: %f", value);
    }
}

// JNI: Get Current Health
extern "C" JNIEXPORT jfloat JNICALL
Java_com_hack_ff_JNIHelper_getCurrentHealth(JNIEnv *env, jobject thiz) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_PlayerBase) {
        uintptr_t hpAddr = g_PlayerBase + OFFSET_HP_FROM_PLAYER_BASE;
        return readMemory<float>(hpAddr);
    }
    return 0.0f;
}

// JNI: Set Position
extern "C" JNIEXPORT void JNICALL
Java_com_hack_ff_JNIHelper_setPosition(JNIEnv *env, jobject thiz, jfloat x, jfloat y, jfloat z) {
    if (g_PlayerBase) {
        uintptr_t posX = g_PlayerBase + 0x200;
        uintptr_t posY = g_PlayerBase + 0x204;
        uintptr_t posZ = g_PlayerBase + 0x208;
        writeMemory<float>(posX, x);
        writeMemory<float>(posY, y);
        writeMemory<float>(posZ, z);
    }
}

// JNI: Toggle Anti-Cheat Bypass
extern "C" JNIEXPORT void JNICALL
Java_com_hack_ff_JNIHelper_toggleAntiCheatBypass(JNIEnv *env, jobject thiz, jboolean enable) {
    LOGI("Anti-Cheat Bypass: %d", enable);
}

// JNI: Toggle Invisibility
extern "C" JNIEXPORT void JNICALL
Java_com_hack_ff_JNIHelper_toggleInvisibility(JNIEnv *env, jobject thiz, jboolean enable) {
    LOGI("Invisibility: %d", enable);
}